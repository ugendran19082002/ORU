---
name: ThanniGo Tech Stack
description: Technology stack, patterns, and conventions for backend and frontend
type: project
originSessionId: 905e7540-e71b-49d0-b266-330b7fcdd2a8
---
## Backend (c:/ugendran/system/backend)
- Node.js + Express.js (ES modules, .js extensions required in imports)
- Sequelize ORM + MySQL2, DB: `thannigo`, host: localhost:3306
- JWT auth + CSRF + Helmet + XSS middleware
- Razorpay for payments/refunds/payouts (test keys in .env)
- Winston logging
- Pattern: Controllers → Services → Models (MVC)
- Response helpers: sendSuccess(res, data, msg), sendError(res, msg, code)
- All routes require authenticateToken; admin routes also require authorize("admin")

## Frontend (c:/ugendran/system/ThanniGoApp)
- React Native 0.81.5 + Expo ~54, TypeScript
- Expo Router (file-based routing) — screens in app/ directory
- NativeWind (TailwindCSS for RN) + StyleSheet for most screens
- Zustand for state (authStore, orderStore, shopStore, etc.)
- Axios via apiClient (c:/ugendran/system/ThanniGoApp/api/client.ts)
- Colors: #005d90 (primary), #006878 (teal), #181c20 (dark text), #f7f9ff (bg)
- All API files use pattern: try { const res = await apiClient.get(...); if (res.data.status === 1) return res.data.data; throw new ApiError(...) } catch (e) { throw ApiError.from(e) }

## Key Environment Variables (backend/.env)
- DB_NAME=thannigo, DB_USER=root, DB_HOST=localhost
- RAZORPAY_KEY_ID=rzp_test_ScRAXavKyLaJfg (test)
- PLATFORM_COMMISSION_PCT defaults to 10%
