# Project Memory Index

- [Project Overview](project_overview.md) — ThanniGo multi-role water delivery platform, full implementation status
- [Tech Stack](tech_stack.md) — Backend: Node.js/Express/Sequelize/MySQL; Frontend: React Native Expo/TypeScript/NativeWind/Zustand
